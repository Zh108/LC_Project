/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/MobinaTeromido/Desktop/prj/ALU/ALU/ALU.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_1242562249;

char *ieee_p_1242562249_sub_3273497107_1035706684(char *, char *, char *, char *, char *, char *);
char *ieee_p_1242562249_sub_3273568981_1035706684(char *, char *, char *, char *, char *, char *);
char *ieee_p_1242562249_sub_342011861_1035706684(char *, char *, char *, char *, char *, char *);
char *ieee_p_1242562249_sub_3696923623_1035706684(char *, char *, char *, char *, char *, char *);
unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );


static void work_a_0832606739_3212880686_p_0(char *t0)
{
    char t53[16];
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    int t13;
    int t14;
    int t15;
    int t16;
    char *t17;
    char *t18;
    int t19;
    char *t20;
    char *t21;
    int t22;
    char *t23;
    int t25;
    char *t26;
    int t28;
    char *t29;
    int t31;
    char *t32;
    int t34;
    char *t35;
    int t37;
    char *t38;
    int t40;
    char *t41;
    int t43;
    char *t44;
    int t46;
    char *t47;
    int t49;
    char *t50;
    int t52;
    char *t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    char *t59;
    char *t60;
    char *t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    unsigned char t68;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    unsigned char t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned char t76;
    unsigned char t77;

LAB0:    xsi_set_current_line(34, ng0);
    t1 = (t0 + 1152U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 5376);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(35, ng0);
    t3 = (t0 + 1032U);
    t4 = *((char **)t3);
    t5 = *((unsigned char *)t4);
    t6 = (t5 == (unsigned char)3);
    if (t6 != 0)
        goto LAB5;

LAB7:    t1 = (t0 + 1832U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t5 = (t2 == (unsigned char)3);
    if (t5 != 0)
        goto LAB8;

LAB9:
LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(36, ng0);
    t3 = xsi_get_transient_memory(8U);
    memset(t3, 0, 8U);
    t7 = t3;
    memset(t7, (unsigned char)2, 8U);
    t8 = (t0 + 5504);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t3, 8U);
    xsi_driver_first_trans_fast(t8);
    xsi_set_current_line(37, ng0);
    t1 = (t0 + 5568);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(38, ng0);
    t1 = (t0 + 5632);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    goto LAB6;

LAB8:    xsi_set_current_line(41, ng0);
    t1 = (t0 + 1352U);
    t4 = *((char **)t1);
    t1 = (t0 + 3088U);
    t7 = *((char **)t1);
    t1 = (t7 + 0);
    memcpy(t1, t4, 8U);
    xsi_set_current_line(42, ng0);
    t1 = (t0 + 1512U);
    t3 = *((char **)t1);
    t1 = (t0 + 3208U);
    t4 = *((char **)t1);
    t1 = (t4 + 0);
    memcpy(t1, t3, 8U);
    xsi_set_current_line(43, ng0);
    t1 = xsi_get_transient_memory(8U);
    memset(t1, 0, 8U);
    t3 = t1;
    memset(t3, (unsigned char)2, 8U);
    t4 = (t0 + 3328U);
    t7 = *((char **)t4);
    t4 = (t7 + 0);
    memcpy(t4, t1, 8U);
    xsi_set_current_line(44, ng0);
    t1 = (t0 + 1672U);
    t3 = *((char **)t1);
    t1 = (t0 + 8553);
    t13 = xsi_mem_cmp(t1, t3, 8U);
    if (t13 == 1)
        goto LAB11;

LAB16:    t7 = (t0 + 8561);
    t14 = xsi_mem_cmp(t7, t3, 8U);
    if (t14 == 1)
        goto LAB11;

LAB17:    t9 = (t0 + 8569);
    t15 = xsi_mem_cmp(t9, t3, 8U);
    if (t15 == 1)
        goto LAB11;

LAB18:    t11 = (t0 + 8577);
    t16 = xsi_mem_cmp(t11, t3, 8U);
    if (t16 == 1)
        goto LAB11;

LAB19:    t17 = (t0 + 8585);
    t19 = xsi_mem_cmp(t17, t3, 8U);
    if (t19 == 1)
        goto LAB12;

LAB20:    t20 = (t0 + 8593);
    t22 = xsi_mem_cmp(t20, t3, 8U);
    if (t22 == 1)
        goto LAB12;

LAB21:    t23 = (t0 + 8601);
    t25 = xsi_mem_cmp(t23, t3, 8U);
    if (t25 == 1)
        goto LAB12;

LAB22:    t26 = (t0 + 8609);
    t28 = xsi_mem_cmp(t26, t3, 8U);
    if (t28 == 1)
        goto LAB12;

LAB23:    t29 = (t0 + 8617);
    t31 = xsi_mem_cmp(t29, t3, 8U);
    if (t31 == 1)
        goto LAB13;

LAB24:    t32 = (t0 + 8625);
    t34 = xsi_mem_cmp(t32, t3, 8U);
    if (t34 == 1)
        goto LAB13;

LAB25:    t35 = (t0 + 8633);
    t37 = xsi_mem_cmp(t35, t3, 8U);
    if (t37 == 1)
        goto LAB13;

LAB26:    t38 = (t0 + 8641);
    t40 = xsi_mem_cmp(t38, t3, 8U);
    if (t40 == 1)
        goto LAB13;

LAB27:    t41 = (t0 + 8649);
    t43 = xsi_mem_cmp(t41, t3, 8U);
    if (t43 == 1)
        goto LAB14;

LAB28:    t44 = (t0 + 8657);
    t46 = xsi_mem_cmp(t44, t3, 8U);
    if (t46 == 1)
        goto LAB14;

LAB29:    t47 = (t0 + 8665);
    t49 = xsi_mem_cmp(t47, t3, 8U);
    if (t49 == 1)
        goto LAB14;

LAB30:    t50 = (t0 + 8673);
    t52 = xsi_mem_cmp(t50, t3, 8U);
    if (t52 == 1)
        goto LAB14;

LAB31:
LAB15:    xsi_set_current_line(60, ng0);
    t1 = (t0 + 5632);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);

LAB10:    xsi_set_current_line(62, ng0);
    t1 = (t0 + 2792U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t5 = (t2 == (unsigned char)3);
    if (t5 != 0)
        goto LAB45;

LAB47:    xsi_set_current_line(65, ng0);
    t1 = (t0 + 3328U);
    t3 = *((char **)t1);
    t1 = (t0 + 5504);
    t4 = (t1 + 56U);
    t7 = *((char **)t4);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t3, 8U);
    xsi_driver_first_trans_fast(t1);

LAB46:    xsi_set_current_line(67, ng0);
    t1 = (t0 + 5568);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB6;

LAB11:    xsi_set_current_line(46, ng0);
    t54 = (t0 + 3088U);
    t55 = *((char **)t54);
    t54 = (t0 + 8468U);
    t56 = (t0 + 3208U);
    t57 = *((char **)t56);
    t56 = (t0 + 8468U);
    t58 = ieee_p_1242562249_sub_3273497107_1035706684(IEEE_P_1242562249, t53, t55, t54, t57, t56);
    t59 = (t0 + 3328U);
    t60 = *((char **)t59);
    t59 = (t60 + 0);
    t61 = (t53 + 12U);
    t62 = *((unsigned int *)t61);
    t63 = (1U * t62);
    memcpy(t59, t58, t63);
    xsi_set_current_line(47, ng0);
    t1 = (t0 + 3088U);
    t3 = *((char **)t1);
    t13 = (7 - 7);
    t62 = (t13 * -1);
    t63 = (1U * t62);
    t64 = (0 + t63);
    t1 = (t3 + t64);
    t5 = *((unsigned char *)t1);
    t4 = (t0 + 3208U);
    t7 = *((char **)t4);
    t14 = (7 - 7);
    t65 = (t14 * -1);
    t66 = (1U * t65);
    t67 = (0 + t66);
    t4 = (t7 + t67);
    t6 = *((unsigned char *)t4);
    t68 = (t5 == t6);
    if (t68 == 1)
        goto LAB36;

LAB37:    t2 = (unsigned char)0;

LAB38:    if (t2 != 0)
        goto LAB33;

LAB35:
LAB34:    goto LAB10;

LAB12:    xsi_set_current_line(51, ng0);
    t1 = (t0 + 3088U);
    t3 = *((char **)t1);
    t1 = (t0 + 8468U);
    t4 = (t0 + 3208U);
    t7 = *((char **)t4);
    t4 = (t0 + 8468U);
    t8 = ieee_p_1242562249_sub_3273568981_1035706684(IEEE_P_1242562249, t53, t3, t1, t7, t4);
    t9 = (t0 + 3328U);
    t10 = *((char **)t9);
    t9 = (t10 + 0);
    t11 = (t53 + 12U);
    t62 = *((unsigned int *)t11);
    t63 = (1U * t62);
    memcpy(t9, t8, t63);
    xsi_set_current_line(52, ng0);
    t1 = (t0 + 3088U);
    t3 = *((char **)t1);
    t13 = (7 - 7);
    t62 = (t13 * -1);
    t63 = (1U * t62);
    t64 = (0 + t63);
    t1 = (t3 + t64);
    t5 = *((unsigned char *)t1);
    t4 = (t0 + 3208U);
    t7 = *((char **)t4);
    t14 = (7 - 7);
    t65 = (t14 * -1);
    t66 = (1U * t65);
    t67 = (0 + t66);
    t4 = (t7 + t67);
    t6 = *((unsigned char *)t4);
    t68 = (t5 != t6);
    if (t68 == 1)
        goto LAB42;

LAB43:    t2 = (unsigned char)0;

LAB44:    if (t2 != 0)
        goto LAB39;

LAB41:
LAB40:    goto LAB10;

LAB13:    xsi_set_current_line(56, ng0);
    t1 = (t0 + 3088U);
    t3 = *((char **)t1);
    t1 = (t0 + 8468U);
    t4 = (t0 + 3208U);
    t7 = *((char **)t4);
    t4 = (t0 + 8468U);
    t8 = ieee_p_1242562249_sub_342011861_1035706684(IEEE_P_1242562249, t53, t3, t1, t7, t4);
    t9 = (t0 + 3328U);
    t10 = *((char **)t9);
    t9 = (t10 + 0);
    t11 = (t53 + 12U);
    t62 = *((unsigned int *)t11);
    t63 = (1U * t62);
    memcpy(t9, t8, t63);
    goto LAB10;

LAB14:    xsi_set_current_line(58, ng0);
    t1 = (t0 + 3088U);
    t3 = *((char **)t1);
    t1 = (t0 + 8468U);
    t4 = (t0 + 3208U);
    t7 = *((char **)t4);
    t4 = (t0 + 8468U);
    t8 = ieee_p_1242562249_sub_3696923623_1035706684(IEEE_P_1242562249, t53, t3, t1, t7, t4);
    t9 = (t0 + 3328U);
    t10 = *((char **)t9);
    t9 = (t10 + 0);
    t11 = (t53 + 12U);
    t62 = *((unsigned int *)t11);
    t63 = (1U * t62);
    memcpy(t9, t8, t63);
    goto LAB10;

LAB32:;
LAB33:    xsi_set_current_line(48, ng0);
    t12 = (t0 + 5632);
    t17 = (t12 + 56U);
    t18 = *((char **)t17);
    t20 = (t18 + 56U);
    t21 = *((char **)t20);
    *((unsigned char *)t21) = (unsigned char)3;
    xsi_driver_first_trans_fast(t12);
    goto LAB34;

LAB36:    t8 = (t0 + 3328U);
    t9 = *((char **)t8);
    t15 = (7 - 7);
    t69 = (t15 * -1);
    t70 = (1U * t69);
    t71 = (0 + t70);
    t8 = (t9 + t71);
    t72 = *((unsigned char *)t8);
    t10 = (t0 + 3088U);
    t11 = *((char **)t10);
    t16 = (7 - 7);
    t73 = (t16 * -1);
    t74 = (1U * t73);
    t75 = (0 + t74);
    t10 = (t11 + t75);
    t76 = *((unsigned char *)t10);
    t77 = (t72 != t76);
    t2 = t77;
    goto LAB38;

LAB39:    xsi_set_current_line(53, ng0);
    t12 = (t0 + 5632);
    t17 = (t12 + 56U);
    t18 = *((char **)t17);
    t20 = (t18 + 56U);
    t21 = *((char **)t20);
    *((unsigned char *)t21) = (unsigned char)3;
    xsi_driver_first_trans_fast(t12);
    goto LAB40;

LAB42:    t8 = (t0 + 3328U);
    t9 = *((char **)t8);
    t15 = (7 - 7);
    t69 = (t15 * -1);
    t70 = (1U * t69);
    t71 = (0 + t70);
    t8 = (t9 + t71);
    t72 = *((unsigned char *)t8);
    t10 = (t0 + 3088U);
    t11 = *((char **)t10);
    t16 = (7 - 7);
    t73 = (t16 * -1);
    t74 = (1U * t73);
    t75 = (0 + t74);
    t10 = (t11 + t75);
    t76 = *((unsigned char *)t10);
    t77 = (t72 != t76);
    t2 = t77;
    goto LAB44;

LAB45:    xsi_set_current_line(63, ng0);
    t1 = xsi_get_transient_memory(8U);
    memset(t1, 0, 8U);
    t4 = t1;
    memset(t4, (unsigned char)2, 8U);
    t7 = (t0 + 5504);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t1, 8U);
    xsi_driver_first_trans_fast(t7);
    goto LAB46;

}

static void work_a_0832606739_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;

LAB0:    xsi_set_current_line(73, ng0);

LAB3:    t1 = (t0 + 2472U);
    t2 = *((char **)t1);
    t1 = (t0 + 5696);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    memcpy(t6, t2, 8U);
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t7 = (t0 + 5392);
    *((int *)t7) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0832606739_3212880686_p_2(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(74, ng0);

LAB3:    t1 = (t0 + 2632U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 5760);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 5408);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0832606739_3212880686_p_3(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;

LAB0:    xsi_set_current_line(75, ng0);

LAB3:    t1 = (t0 + 2792U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 5824);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast_port(t1);

LAB2:    t8 = (t0 + 5424);
    *((int *)t8) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}


extern void work_a_0832606739_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0832606739_3212880686_p_0,(void *)work_a_0832606739_3212880686_p_1,(void *)work_a_0832606739_3212880686_p_2,(void *)work_a_0832606739_3212880686_p_3};
	xsi_register_didat("work_a_0832606739_3212880686", "isim/ALU_T_isim_beh.exe.sim/work/a_0832606739_3212880686.didat");
	xsi_register_executes(pe);
}
