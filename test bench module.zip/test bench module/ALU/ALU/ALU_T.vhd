--------------------------------------------------------------------------------
-- Company: 
-- Engineer:
--
-- Create Date:   14:03:53 08/10/2025
-- Design Name:   
-- Module Name:   C:/Users/MobinaTeromido/Desktop/prj/ALU/ALU/ALU_T.vhd
-- Project Name:  ALU
-- Target Device:  
-- Tool versions:  
-- Description:   
-- 
-- VHDL Test Bench Created by ISE for module: ALU
-- 
-- Dependencies:
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
-- Notes: 
-- This testbench has been automatically generated using types std_logic and
-- std_logic_vector for the ports of the unit under test.  Xilinx recommends
-- that these types always be used for the top-level I/O of a design in order
-- to guarantee that the testbench will bind correctly to the post-implementation 
-- simulation model.
--------------------------------------------------------------------------------
LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
 
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--USE ieee.numeric_std.ALL;
 
ENTITY ALU_T IS
END ALU_T;
 
ARCHITECTURE behavior OF ALU_T IS 
 
    -- Component Declaration for the Unit Under Test (UUT)
 
    COMPONENT ALU
    PORT(
         Rst : IN  std_logic;
         clk : IN  std_logic;
         data1 : IN  std_logic_vector(7 downto 0);
         data2 : IN  std_logic_vector(7 downto 0);
         Func : IN  std_logic_vector(7 downto 0);
         enable : IN  std_logic;
         Result : OUT  std_logic_vector(7 downto 0);
         done : OUT  std_logic;
         Overflow : OUT  std_logic
        );
    END COMPONENT;
    

   --Inputs
   signal Rst : std_logic := '0';
   signal clk : std_logic := '0';
   signal data1 : std_logic_vector(7 downto 0) := (others => '0');
   signal data2 : std_logic_vector(7 downto 0) := (others => '0');
   signal Func : std_logic_vector(7 downto 0) := (others => '0');
   signal enable : std_logic := '0';

 	--Outputs
   signal Result : std_logic_vector(7 downto 0);
   signal done : std_logic;
   signal Overflow : std_logic;

   -- Clock period definitions
   constant clk_period : time := 10 ns;
 
BEGIN
 
	-- Instantiate the Unit Under Test (UUT)
   uut: ALU PORT MAP (
          Rst => Rst,
          clk => clk,
          data1 => data1,
          data2 => data2,
          Func => Func,
          enable => enable,
          Result => Result,
          done => done,
          Overflow => Overflow
        );

   -- Clock process definitions
   clk_process :process
   begin
		clk <= '0';
		wait for clk_period/2;
		clk <= '1';
		wait for clk_period/2;
   end process;
 

   -- Stimulus process
   stim_proc: process
   begin		
      Rst <= '1' ;
		wait for 2* clk_period;
		Rst <= '0' ;
		wait for clk_period ;
		data1 <= std_logic_vector ( to_signed( 10 , 8));
		data2 <= std_logic_vector ( to_signed( 90 , 8));
		
		Func <= "00000011"; -- and
		enable <= '1' ;
      wait for 100 ns;	
		enable <= '0' ;
		

      wait for clk_period*10;

      -- insert stimulus here 

      wait;
   end process;

END;
