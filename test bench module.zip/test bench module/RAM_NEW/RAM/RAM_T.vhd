
LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
 

ENTITY RAM_T IS
END RAM_T;
 
ARCHITECTURE behavior OF RAM_T IS 
 
    -- Component Declaration for the Unit Under Test (UUT)
 
    COMPONENT RAM
    PORT(
         clk : IN  std_logic;
         Rst : IN  std_logic;
         Write_Adr : IN  std_logic_vector(4 downto 0);
         WriteEn : IN  std_logic;
         Wr_Data : IN  std_logic_vector(7 downto 0);
         Read_Adr : IN  std_logic_vector(4 downto 0);
         ReadEn : IN  std_logic;
         Output : OUT  std_logic_vector(7 downto 0);
         wr_data_ack : OUT  std_logic;
         OutputRdy : OUT  std_logic
        );
    END COMPONENT;
    

   --Inputs
   signal clk : std_logic := '0';
   signal Rst : std_logic := '0';
   signal Write_Adr : std_logic_vector(4 downto 0) := (others => '0');
   signal WriteEn : std_logic := '0';
   signal Wr_Data : std_logic_vector(7 downto 0) := (others => '0');
   signal Read_Adr : std_logic_vector(4 downto 0) := (others => '0');
   signal ReadEn : std_logic := '0';

 	--Outputs
   signal Output : std_logic_vector(7 downto 0);
   signal wr_data_ack : std_logic;
   signal OutputRdy : std_logic;

   -- Clock period definitions
   constant clk_period : time := 10 ns;
 
BEGIN
 
	-- Instantiate the Unit Under Test (UUT)
   uut: RAM PORT MAP (
          clk => clk,
          Rst => Rst,
          Write_Adr => Write_Adr,
          WriteEn => WriteEn,
          Wr_Data => Wr_Data,
          Read_Adr => Read_Adr,
          ReadEn => ReadEn,
          Output => Output,
          wr_data_ack => wr_data_ack,
          OutputRdy => OutputRdy
        );

   -- Clock process definitions
   clk_process :process
   begin
		clk <= '0';
		wait for clk_period/2;
		clk <= '1';
		wait for clk_period/2;
   end process;
 

   -- Stimulus process
   stim_proc: process
   begin		
      -- hold reset state for 100 ns.
        wait for 25 ns;
      
		-- write data in Ram
		WriteEn <='1';
      Write_Adr <="00001"; -- address
      Wr_Data <= "00001111"; -- data
      wait for clk_period;
      WriteEn <= '0';
		
      wait for 50 ns;
		
		-- read data from Ram
      Read_Adr <= "00001";
      ReadEn <='1';
      wait for 305 ns;
      ReadEn <='0';	
      wait for 25 ns;
		
		Rst <= '1' ; -- reset
		
		wait for 50 ns;
		Rst <='0';
		wait for 50 ns;
		
      WriteEn <='1';
      Write_Adr <="00010";
	   Wr_Data <= "01010101";
      wait for 50 ns;
      Read_Adr <= "00010";
		WriteEn<='0';
      ReadEn <='1';
		
      wait for 25 ns;
		ReadEn <='0';
			

      wait for clk_period*10;

      -- insert stimulus here 

      wait;
   end process;

END;
