library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity checksum_cal is
    Generic(
	         MAX_LEN :integer :=8 );
    Port ( Data : in  STD_LOGIC_VECTOR (7 downto 0);
	        dataarray : in ByteArray ;
           Length : in INTEGER range 1 to MAX_LEN;
           start : in  STD_LOGIC;
           ChecksumH : out  STD_LOGIC_VECTOR (7 downto 0);
           ChecksumL : out  STD_LOGIC_VECTOR (7 downto 0);
           ready : out  STD_LOGIC);
end checksum_cal;

architecture Behavioral of checksum_cal is
type ByteArray is array ( 0 to MAX_LEN -1 ) of std_logic_vector( 7 downto 0 ) ;

begin
process ( dataarray , Length ,start )
variable sum : integer :=0 ;

begin
    if start = '1' then
	     sum := 0 ;
		  for i in 0 to  Length-1 loop
				sum := sum + to_integer (unsigned(dataarray(i)));
				end loop ;
				ChecksumH <= std_logic_vector(to_unsigned((sum /256) mod 256 , 8 ));
				ChecksumL <= std_logic_vector(to_unsigned( sum mod 256 , 8 ));
				ready <= '1' ;
	 else 
	 ChecksumH <= ( others => '0' );
	 ChecksumL <= ( others => '0' );
	 ready     <= '0';
	 end if;
end process;

end Behavioral;

