--------------------------------------------------------------------------------
-- Company: 
-- Engineer:
--
-- Create Date:   17:14:40 08/08/2025
-- Design Name:   
-- Module Name:   C:/Users/MobinaTeromido/Desktop/prj/checksum/checksum/checksum_T.vhd
-- Project Name:  checksum
-- Target Device:  
-- Tool versions:  
-- Description:   
-- 
-- VHDL Test Bench Created by ISE for module: checksum
-- 
-- Dependencies:
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
-- Notes: 
-- This testbench has been automatically generated using types std_logic and
-- std_logic_vector for the ports of the unit under test.  Xilinx recommends
-- that these types always be used for the top-level I/O of a design in order
-- to guarantee that the testbench will bind correctly to the post-implementation 
-- simulation model.
--------------------------------------------------------------------------------
LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
 
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--USE ieee.numeric_std.ALL;
 
ENTITY checksum_T IS
END checksum_T;
 
ARCHITECTURE behavior OF checksum_T IS 
 
    -- Component Declaration for the Unit Under Test (UUT)
 
    COMPONENT checksum
    PORT(
         clk : IN  std_logic;
         Rst : IN  std_logic;
         start : IN  std_logic;
         byte_count : IN  INTEGER range 2 to 4;
         byte0 : IN  std_logic_vector(7 downto 0);
         byte1 : IN  std_logic_vector(7 downto 0);
         byte2 : IN  std_logic_vector(7 downto 0);
         byte3 : IN  std_logic_vector(7 downto 0);
			byte4 : IN  std_logic_vector(7 downto 0);
         checksumH : OUT  std_logic_vector(7 downto 0);
         checksumL : OUT  std_logic_vector(7 downto 0);
         ready : OUT  std_logic
        );
    END COMPONENT;
    

   --Inputs
   signal clk : std_logic := '0';
   signal Rst : std_logic := '0';
   signal start : std_logic := '0';
   signal byte_count : INTEGER range 2 to 4 := 4 ;
   signal byte0 : std_logic_vector(7 downto 0) := (others => '0');
   signal byte1 : std_logic_vector(7 downto 0) := (others => '0');
   signal byte2 : std_logic_vector(7 downto 0) := (others => '0');
   signal byte3 : std_logic_vector(7 downto 0) := (others => '0');
	signal byte4 : std_logic_vector(7 downto 0) := (others => '0');

 	--Outputs
   signal checksumH : std_logic_vector(7 downto 0);
   signal checksumL : std_logic_vector(7 downto 0);
   signal ready : std_logic;

   -- Clock period definitions
   constant clk_period : time := 10 ns;
 
BEGIN
 
	-- Instantiate the Unit Under Test (UUT)
   uut: checksum PORT MAP (
          clk => clk,
          Rst => Rst,
          start => start,
          byte_count => byte_count,
          byte0 => byte0,
          byte1 => byte1,
          byte2 => byte2,
          byte3 => byte3,
			 byte4 => byte4,
          checksumH => checksumH,
          checksumL => checksumL,
          ready => ready
        );

   -- Clock process definitions
   clk_process :process
   begin
		clk <= '0';
		wait for clk_period/2;
		clk <= '1';
		wait for clk_period/2;
   end process;
 

   -- Stimulus process
   stim_proc: process
   begin		
      -- hold reset state for 100 ns.
		Rst <= '1';
      wait for 100 ns;	
      Rst <= '0' ;
		--- sum is 344     checksumh is not 00000000 
		byte0 <= "10111111"; 
		byte1 <= x"22"; --34
		byte2 <= x"33"; --51
		byte3 <= x"44"; -- 68
		byte_count <= 4 ;
		
		
		wait for 50 ns;
		start <= '1';
		wait for 100 ns ;
		start <= '0';
		wait for 200 ns;
		
		byte0 <= x"05";
		byte1 <= x"0A";
		byte2 <= x"0F";
		byte_count <= 3;
		wait for 50 ns;
		start <= '1';
		wait for 100 ns;
		start <= '0';
		
		
      wait for clk_period*10;

      -- insert stimulus here 

      wait;
   end process;

END;
