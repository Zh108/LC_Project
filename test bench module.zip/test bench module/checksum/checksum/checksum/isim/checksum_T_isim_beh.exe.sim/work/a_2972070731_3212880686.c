/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/MobinaTeromido/Desktop/prj/checksum/checksum/checksum.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_1242562249;

char *ieee_p_1242562249_sub_1547198987_1035706684(char *, char *, char *, char *, char *, char *);
char *ieee_p_1242562249_sub_2045698577_1035706684(char *, char *, char *, char *, int );
unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );


static void work_a_2972070731_3212880686_p_0(char *t0)
{
    char t13[16];
    char t14[16];
    char t15[16];
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t16;
    char *t17;
    unsigned int t18;
    unsigned int t19;
    int t20;
    unsigned int t21;

LAB0:    xsi_set_current_line(30, ng0);
    t1 = (t0 + 992U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 4552);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(32, ng0);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t5 = *((unsigned char *)t4);
    t6 = (t5 == (unsigned char)3);
    if (t6 != 0)
        goto LAB5;

LAB7:    xsi_set_current_line(39, ng0);
    t1 = (t0 + 1352U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t5 = (t2 == (unsigned char)3);
    if (t5 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(56, ng0);
    t1 = (t0 + 4824);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(57, ng0);
    t1 = xsi_get_transient_memory(8U);
    memset(t1, 0, 8U);
    t3 = t1;
    memset(t3, (unsigned char)2, 8U);
    t4 = (t0 + 4632);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 8U);
    xsi_driver_first_trans_fast_port(t4);
    xsi_set_current_line(58, ng0);
    t1 = xsi_get_transient_memory(8U);
    memset(t1, 0, 8U);
    t3 = t1;
    memset(t3, (unsigned char)2, 8U);
    t4 = (t0 + 4696);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 8U);
    xsi_driver_first_trans_fast_port(t4);

LAB9:
LAB6:    goto LAB3;

LAB5:    xsi_set_current_line(33, ng0);
    t3 = xsi_get_transient_memory(8U);
    memset(t3, 0, 8U);
    t7 = t3;
    memset(t7, (unsigned char)2, 8U);
    t8 = (t0 + 4632);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t3, 8U);
    xsi_driver_first_trans_fast_port(t8);
    xsi_set_current_line(34, ng0);
    t1 = xsi_get_transient_memory(8U);
    memset(t1, 0, 8U);
    t3 = t1;
    memset(t3, (unsigned char)2, 8U);
    t4 = (t0 + 4696);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 8U);
    xsi_driver_first_trans_fast_port(t4);
    xsi_set_current_line(35, ng0);
    t1 = xsi_get_transient_memory(16U);
    memset(t1, 0, 16U);
    t3 = t1;
    memset(t3, (unsigned char)2, 16U);
    t4 = (t0 + 4760);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 16U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(36, ng0);
    t1 = (t0 + 4824);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB6;

LAB8:    xsi_set_current_line(40, ng0);
    t1 = (t0 + 1672U);
    t4 = *((char **)t1);
    t1 = (t0 + 7512U);
    t7 = ieee_p_1242562249_sub_2045698577_1035706684(IEEE_P_1242562249, t14, t4, t1, 16);
    t8 = (t0 + 1832U);
    t9 = *((char **)t8);
    t8 = (t0 + 7528U);
    t10 = ieee_p_1242562249_sub_2045698577_1035706684(IEEE_P_1242562249, t15, t9, t8, 16);
    t11 = ieee_p_1242562249_sub_1547198987_1035706684(IEEE_P_1242562249, t13, t7, t14, t10, t15);
    t12 = (t0 + 3248U);
    t16 = *((char **)t12);
    t12 = (t16 + 0);
    t17 = (t13 + 12U);
    t18 = *((unsigned int *)t17);
    t19 = (1U * t18);
    memcpy(t12, t11, t19);
    xsi_set_current_line(41, ng0);
    t1 = (t0 + 1512U);
    t3 = *((char **)t1);
    t20 = *((int *)t3);
    t2 = (t20 >= 3);
    if (t2 != 0)
        goto LAB11;

LAB13:
LAB12:    xsi_set_current_line(44, ng0);
    t1 = (t0 + 1512U);
    t3 = *((char **)t1);
    t20 = *((int *)t3);
    t2 = (t20 >= 4);
    if (t2 != 0)
        goto LAB14;

LAB16:
LAB15:    xsi_set_current_line(47, ng0);
    t1 = (t0 + 1512U);
    t3 = *((char **)t1);
    t20 = *((int *)t3);
    t2 = (t20 == 5);
    if (t2 != 0)
        goto LAB17;

LAB19:
LAB18:    xsi_set_current_line(51, ng0);
    t1 = (t0 + 3248U);
    t3 = *((char **)t1);
    t1 = (t0 + 4760);
    t4 = (t1 + 56U);
    t7 = *((char **)t4);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memcpy(t9, t3, 16U);
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(52, ng0);
    t1 = (t0 + 3248U);
    t3 = *((char **)t1);
    t18 = (15 - 15);
    t19 = (t18 * 1U);
    t21 = (0 + t19);
    t1 = (t3 + t21);
    t4 = (t0 + 4632);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 8U);
    xsi_driver_first_trans_fast_port(t4);
    xsi_set_current_line(53, ng0);
    t1 = (t0 + 3248U);
    t3 = *((char **)t1);
    t18 = (15 - 7);
    t19 = (t18 * 1U);
    t21 = (0 + t19);
    t1 = (t3 + t21);
    t4 = (t0 + 4696);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t1, 8U);
    xsi_driver_first_trans_fast_port(t4);
    xsi_set_current_line(54, ng0);
    t1 = (t0 + 4824);
    t3 = (t1 + 56U);
    t4 = *((char **)t3);
    t7 = (t4 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)3;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB9;

LAB11:    xsi_set_current_line(42, ng0);
    t1 = (t0 + 3248U);
    t4 = *((char **)t1);
    t1 = (t0 + 7640U);
    t7 = (t0 + 1992U);
    t8 = *((char **)t7);
    t7 = (t0 + 7544U);
    t9 = ieee_p_1242562249_sub_2045698577_1035706684(IEEE_P_1242562249, t14, t8, t7, 16);
    t10 = ieee_p_1242562249_sub_1547198987_1035706684(IEEE_P_1242562249, t13, t4, t1, t9, t14);
    t11 = (t0 + 3248U);
    t12 = *((char **)t11);
    t11 = (t12 + 0);
    t16 = (t13 + 12U);
    t18 = *((unsigned int *)t16);
    t19 = (1U * t18);
    memcpy(t11, t10, t19);
    goto LAB12;

LAB14:    xsi_set_current_line(45, ng0);
    t1 = (t0 + 3248U);
    t4 = *((char **)t1);
    t1 = (t0 + 7640U);
    t7 = (t0 + 2152U);
    t8 = *((char **)t7);
    t7 = (t0 + 7560U);
    t9 = ieee_p_1242562249_sub_2045698577_1035706684(IEEE_P_1242562249, t14, t8, t7, 16);
    t10 = ieee_p_1242562249_sub_1547198987_1035706684(IEEE_P_1242562249, t13, t4, t1, t9, t14);
    t11 = (t0 + 3248U);
    t12 = *((char **)t11);
    t11 = (t12 + 0);
    t16 = (t13 + 12U);
    t18 = *((unsigned int *)t16);
    t19 = (1U * t18);
    memcpy(t11, t10, t19);
    goto LAB15;

LAB17:    xsi_set_current_line(48, ng0);
    t1 = (t0 + 3248U);
    t4 = *((char **)t1);
    t1 = (t0 + 7640U);
    t7 = (t0 + 2312U);
    t8 = *((char **)t7);
    t7 = (t0 + 7576U);
    t9 = ieee_p_1242562249_sub_2045698577_1035706684(IEEE_P_1242562249, t14, t8, t7, 16);
    t10 = ieee_p_1242562249_sub_1547198987_1035706684(IEEE_P_1242562249, t13, t4, t1, t9, t14);
    t11 = (t0 + 3248U);
    t12 = *((char **)t11);
    t11 = (t12 + 0);
    t16 = (t13 + 12U);
    t18 = *((unsigned int *)t16);
    t19 = (1U * t18);
    memcpy(t11, t10, t19);
    goto LAB18;

}


extern void work_a_2972070731_3212880686_init()
{
	static char *pe[] = {(void *)work_a_2972070731_3212880686_p_0};
	xsi_register_didat("work_a_2972070731_3212880686", "isim/checksum_T_isim_beh.exe.sim/work/a_2972070731_3212880686.didat");
	xsi_register_executes(pe);
}
