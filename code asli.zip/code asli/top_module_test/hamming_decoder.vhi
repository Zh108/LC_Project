
-- VHDL Instantiation Created from source file hamming_decoder.vhd -- 14:58:43 08/16/2025
--
-- Notes: 
-- 1) This instantiation template has been automatically generated using types
-- std_logic and std_logic_vector for the ports of the instantiated module
-- 2) To use this template to instantiate this entity, cut-and-paste and then edit

	COMPONENT hamming_decoder
	PORT(
		DataIn : IN std_logic_vector(12 downto 0);
		clk : IN std_logic;
		Rst : IN std_logic;
		Odd_Mode : IN std_logic;          
		Output : OUT std_logic;
		Valid : OUT std_logic
		);
	END COMPONENT;

	Inst_hamming_decoder: hamming_decoder PORT MAP(
		DataIn => ,
		clk => ,
		Rst => ,
		Odd_Mode => ,
		Output => ,
		Valid => 
	);


