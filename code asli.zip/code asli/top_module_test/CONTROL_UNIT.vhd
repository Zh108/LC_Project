-- control unit asli ( be onvan rabet baraye ram va alu)
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values


-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity controlUnit_asli is
    Port ( 
			  clk : in STD_LOGIC;
			  rst : in STD_LOGIC;
			  func : in  STD_LOGIC_VECTOR (7 downto 0);
			  -- packet_valid : in STD_LOGIC;
			  checkSumH, checkSumL : in  STD_LOGIC_VECTOR (7 downto 0);
			  computedH, computedL : in  STD_LOGIC_VECTOR (7 downto 0);
			  lengthh : in  STD_LOGIC_VECTOR (7 downto 0);
           write_en : out  STD_LOGIC;
           read_en : out  STD_LOGIC;
			  outputRdy : out  STD_LOGIC;
			  error : out  STD_LOGIC;
           alu_en : out  STD_LOGIC);
end controlUnit_asli;

architecture Behavioral of controlUnit_asli is

	 type State_Type is ( 
        START, CHECKSUM, OPERAND1, OPERAND2, OPERAND3, OPERAND4, IMM1, IMM2, IMM3, ARRAY_LOOP1, ARRAY_LOOP2, ARRAY_LOOP3, INDIRECT1, INDIRECT2, INDIRECT3, INDIRECT4, WRITE_OP, READ1, READ2, DONE, ERROR_STATE
    );
    signal current_state : State_Type := START;
	 signal counter : integer := 0;
	 signal len : integer := 0;
	 
begin
	 process(clk,rst,checkSumH,computedH,checksumL,computedL) --be dalil inke betoonim compare konim
	 begin
		if rising_edge(clk) then
			if rst = '1' then
				current_state <= START;
				alu_en <= '0';
				write_en <= '0';
				read_en <= '0';
				outputRdy <= '0';
				error <= '0';
				counter <= 0;
				len <= 0;
			else
				case current_state is
					when START =>
						alu_en <= '0';
						write_en <= '0';
						read_en <= '0';
						outputRdy <= '0';
						error <= '0';
						-- if packet_valid = '1' then
						current_state <= checksum;
						--end if;
					
					when CHECKSUM =>
						if ( checkSumH = computedH) and (checksumL = computedL) then
							case func is 
								when "00000000" | "00000001" | "00000010" | "00000011" =>     --operand alu
									current_state <= OPERAND1;
								when "00111100" | "00111101" | "00111110" | "00111111" =>     --immediate alu
									current_state <= IMM1;
								when "11000000" | "11000001" | "11000010" | "11000011" =>     --arrau alu
									current_state <= ARRAY_LOOP1;
									len <= to_integer(unsigned(lengthh));
									counter <= 0;
								when "00110000" | "00110001" | "00110010" | "00110011" =>      --indirect alu
									current_state <= INDIRECT1;
								when "11110000" =>     --write
									current_state <= WRITE_OP;
								when "00001111" =>     --read
									current_state <= READ1;
								when others =>         --error
									current_state <= ERROR_STATE;
							end case;
						else
							current_state <= ERROR_STATE;
						end if;
						
					when OPERAND1 =>   --OPERAND ALU
						read_en <= '1';                         --%%%% NABAYAD BE RAM BEGIM DAGHIGHAN CHIO BEKHONE?
						current_state <= OPERAND2;
					when OPERAND2 =>   
						read_en <= '1';                         --%%%% AZ OONJAYI KE RASMAN FARGHI BA GHABLI NADARE RAH BEHTARI NIST KE BEYN ADDR1 ADDR2 TAFAVOT BASHE?
						current_state <= OPERAND3;
					when OPERAND3 =>
						read_en <= '0';
						alu_en <='1';
						current_state <= OPERAND4;              --%%%% MAN 3 TA KARDAM CHON ON CODE KE MOBINA FERESTADE WRITE VA ALU BAHAMAN
					when OPERAND4 =>
						read_en <= '0';
						alu_en <='0';
						write_en <= '1';
						current_state <= DONE;
					
					when IMM1 =>       --IMMIDIATE ALU
						read_en <= '1';
						current_state <= IMM2;
					when IMM2 =>       
						read_en <= '0';
						alu_en <='1';
						current_state <= IMM3;
					when IMM3 =>
						read_en <= '0';
						alu_en <='0';
						write_en <= '1';
						current_state <= DONE;                   --%%%%BE HAMOON DALIL GHABLI 3 TA KARDAM
			
						
					when ARRAY_LOOP1 =>      --Array ALU
						if counter < len then
							read_en <= '1' ;
							current_state <= ARRAY_LOOP2;
						else
							read_en <= '0';
							alu_en <= '0' ;
							write_en <= '0';
							current_state <= DONE;
						end if;
					when ARRAY_LOOP2 =>
						alu_en <= '1';
						current_state <= ARRAY_LOOP3;
					when ARRAY_LOOP3 =>
						write_en <= '1';
						counter <= counter + 1;
						current_state <= ARRAY_LOOP1;
						
						
					when INDIRECT1 =>        --INDIRECT ALU
						read_en <= '1';                                      --dataye tooye address to bekhone
						current_state <= INDIRECT2;
					when INDIRECT2 =>
						read_en <= '1';
					   current_state <= INDIRECT3;                          --dataye tooye adressi ke be dast avordimo bekhoone
					when INDIRECT3 =>
						read_en <='0';
						alu_en <= '1';
						current_state <= INDIRECT4;
					when INDIRECT4 =>
						alu_en <= '0';
						write_en <= '1';
						current_state <= DONE;
					
					when WRITE_OP =>        --WRITE
						write_en <= '1';
						current_state <= DONE;
					
					when READ1 =>         --READ
						read_en <= '1';
						current_state <= READ2;
					when READ2 =>
						read_en <= '0';
						outputRdy <= '1';
						current_state <= DONE;
					
					when DONE =>
						alu_en <= '0';
						read_en <= '0';
						write_en <= '0';
						outputRDY <= '0';
						current_state <= START;
						
					when ERROR_STATE =>
						error <= '1';
						current_state <= START;
							
				end case;
			end if;
		
		end if;
		
	 end process;

end Behavioral;

