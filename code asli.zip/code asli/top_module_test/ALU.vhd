library IEEE;                                                          -- Mobina Teromideh  40223021
use IEEE.STD_LOGIC_1164.ALL;                                           -- Zahra Heydari     40223028
use IEEE.NUMERIC_STD.ALL;


entity ALU is                                                           
    port(
	     Rst : in STD_LOGIC ;
		  clk : in STD_LOGIC ;
	     data1 : in STD_LOGIC_VECTOR( 7 downto 0);
		  data2 : in STD_LOGIC_VECTOR( 7 downto 0);
		  Func : in STD_LOGIC_VECTOR ( 7 downto 0);  -- it is in control unit
		  enable : in STD_LOGIC ;
		  Result : out STD_LOGIC_VECTOR ( 7 downto 0);
		  done : out STD_LOGIC ;
		  Overflow : out STD_LOGIC );  -- for any errors like overflow
		  
end ALU;

architecture Behavioral of ALU is


signal res_reg : std_logic_vector( 7 downto 0) := ( others =>'0') ;
signal done_reg : std_logic := '0' ;
signal overflow_reg : std_logic := '0' ;



begin

process(clk)
variable s_1 , s_2 , r_s :signed( 7 downto 0);  -- data1(signed) , data2(signed) , result(signed)
begin
    if rising_edge(clk) then
	     if Rst ='1' then
		      res_reg <= ( others => '0' ) ;
				done_reg <= '0';
				overflow_reg <= '0' ;
			
		  elsif enable = '1' then 
		      s_1 := signed( data1) ;
				s_2 := signed( data2) ;
				r_s := ( others => '0' ) ;
			   case Func is   
	         
		        when  "00000000"| "00111100" | "11000000" | "00110000" => r_s := s_1 + s_2  ; -- Add
				  if ( s_1(7) = s_2( 7)) and (r_s(7) /= s_1(7)) then -- last bit of two data is same
				     overflow_reg <= '1' ;                           -- but the last bit of result is not same
				  end if;
				 
		        when  "00000001"| "00111101" | "11000001" | "00110001" => r_s := s_1 - s_2  ; -- Sub
				  if ( s_1(7) /= s_2(7)) and (r_s(7) /= s_1(7)) then
				     overflow_reg <= '1' ;
				  end if;
				
		        when  "00000010"| "00111110" | "11000010" | "00110010" => r_s := s_1 or s_2 ; --OR
				
		        when  "00000011"| "00111111" | "11000011" | "00110011" => r_s := s_1 and s_2 ; --AND

		        when others => overflow_reg <= '1' ; -- invalid 
		      end case;
				if overflow_reg = '1' then
				   res_reg <= ( others => '0') ;
				else
		         res_reg <= std_logic_vector(r_s);
		      end if;
				done_reg <= '1' ;
			end if;
				
	 end if;
end process;
      
		 Result <= res_reg;
		 done   <= done_reg ;
		 overflow <= overflow_reg ;

end Behavioral;
