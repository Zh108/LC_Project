--Zahra Heydari _ 40223028 _ decoder
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;


entity hamming_decoder is
    Port ( DataIn : in  STD_LOGIC_VECTOR (12 downto 0);
			  clk : in  STD_LOGIC;
			  Rst : in  STD_LOGIC;
           Odd_Mode : in  STD_LOGIC;
           DataOut : out STD_LOGIC_VECTOR(7 downto 0);
           Valid : out  STD_LOGIC);
end hamming_decoder;

architecture Behavioral of hamming_decoder is
		signal d : STD_LOGIC_VECTOR(12 downto 0);
		signal temp : STD_LOGIC_VECTOR(12 downto 0);
		signal syndrome : STD_LOGIC_VECTOR(3 downto 0);
		signal corrected : STD_LOGIC_VECTOR(12 downto 0);
		signal parity_all : STD_LOGIC;
		signal parity_check : STD_LOGIC;
		signal bit_counter : integer range 0 to 7 :=0;
		

begin

		d <= DataIn;

		-- check for single bit error
		syndrome(0) <= d(0) xor d(2) xor d(4) xor d(6) xor d(8) xor d(10) xor Odd_Mode;
		syndrome(1) <= d(1) xor d(2) xor d(5) xor d(6) xor d(9) xor d(10) xor Odd_Mode;
		syndrome(2) <= d(3) xor d(4) xor d(5) xor d(6) xor d(11) xor Odd_Mode;
		syndrome(3) <= d(7) xor d(8) xor d(9) xor d(10) xor d(11) xor Odd_Mode;
		
		-- Overall parity (excluding bit 12)
		parity_all <= DataIn(0) xor DataIn(1) xor DataIn(2) xor DataIn(3) xor
                  DataIn(4) xor DataIn(5) xor DataIn(6) xor DataIn(7) xor
                  DataIn(8) xor DataIn(9) xor DataIn(10) xor DataIn(11) ;

		-- XOR with received parity bit (bit 12) to check parity
		parity_check <= parity_all xor DataIn(12);
	 
		--correct the error
		temp <= "0000000000000";
		--temp(to_integer(unsigned(syndrome))) <= temp(to_integer(unsigned(syndrome))) or '1';
		corrected <= d xor temp;

		
	 
		-- extract data
		DataOut(0) <= corrected(2);
		DataOut(1) <= corrected(4);
		DataOut(2) <= corrected(5);
		DataOut(3) <= corrected(6);
		DataOut(4) <= corrected(8);
		DataOut(5) <= corrected(9);
		DataOut(6) <= corrected(10);
		DataOut(7) <= corrected(11);

		-- valid = 1 if no uncorrectable errors
		Valid <= parity_check or (not(syndrome(0)) and  not(syndrome(1)) and not(syndrome(2)) and not(syndrome(3)));
		
		-- serialize
--		process (clk)
--		begin
--			if rising_edge(clk) then
--				if Rst = '1' then
--					bit_counter<= 0;
--					Output <= '0'; -- reset
--				else
--					if bit_counter <8 then
--						Output <= DataOut(bit_counter);
--						bit_counter <= bit_counter +1 ;
--					else
--						bit_counter <= 0 ;
--					end if;
--				end if;
--			end if;
--		end process;

	


end Behavioral;

