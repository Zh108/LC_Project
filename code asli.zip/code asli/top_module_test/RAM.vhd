library IEEE;                                                          -- Mobina Teromideh   40223021
use IEEE.STD_LOGIC_1164.ALL;                                           -- Zahra Heydari      40223028
use IEEE.NUMERIC_STD.ALL;

entity RAM is
    Port ( clk : in  STD_LOGIC;
           Rst : in  STD_LOGIC;
           Write_Adr : in  STD_LOGIC_VECTOR (7 downto 0); -- 5 bits can make 32 locations
           WriteEn : in  STD_LOGIC;
           Wr_Data : in  STD_LOGIC_VECTOR (7 downto 0);  -- our data is 8 bits
           Read_Adr : in  STD_LOGIC_VECTOR (7 downto 0);
           ReadEn : in  STD_LOGIC;
           Output : out  STD_LOGIC_VECTOR (7 downto 0);
			  wr_data_ack : out std_logic ; -- we added this for checking the process of writing
           OutputRdy : out  STD_LOGIC);
end RAM;

architecture Behavioral of RAM is

    -- 32 places , each one is 8 bits
    type ram_array is array (0 to 31) of std_logic_vector(7 downto 0);
    signal ram_memory : ram_array ;  -- first they don't have any value
	 
	 -- for latency :(2 clk) writing
	 signal write_adr1  : std_logic_vector(7 downto 0);
	 signal write_data1 : std_logic_vector(7 downto 0);
	 signal write_en1   : std_logic ;
	 
	 signal write_adr2  : std_logic_vector(7 downto 0);
	 signal write_data2 : std_logic_vector(7 downto 0);
	 signal write_en2   : std_logic ;
	 
	 -- for understanding the Latency of writing 
	 signal write_data : std_logic;
	 
    -- for latency :(2 clk) reading
    signal read_adr1 : std_logic_vector(7 downto 0);
    signal read_en1  : std_logic ;
	 
	 signal read_adr2 : std_logic_vector(7 downto 0); 
    signal read_en2  : std_logic ;
	 
	 

begin

    -- Write Process 
    process(clk)
    begin
        if rising_edge(clk) then
		     if Rst ='1' then
               ram_memory <= ( others => ( others => '0'));	
					
               write_adr1 <= (others => '0');
               write_data1 <= (others => '0');
					write_en1  <= '0';
					
  				   write_adr2 <= (others => '0');
					write_data2 <= (others => '0');
               write_en2  <= '0';
				
					write_data <= '0';				
          
           else
               --  address,data and enableling for the first cycle
               write_adr1 <= Write_Adr;
				   write_data1 <= Wr_Data ;
               write_en1  <= WriteEn;

               -- address,data and enableling for the second cycle
               write_adr2 <= write_adr1;
				   write_data2 <= write_data1;
               write_en2  <= write_en1;
            
				   -- after two rising_edge from enabeling the data is ready
               if write_en2 = '1' then
				
                  ram_memory(to_integer(unsigned(write_adr2))) <= write_data2;	 
					   write_data <='1';
				   else
				      write_data <='0';
               end if;
			   end if;
        end if;
		  
    end process;
    
	 wr_data_ack <= write_data ;
    
    -- Read Process 
    process(clk)
    begin
        if rising_edge(clk) then
		     if Rst = '1' then 
             read_adr1 <= (others => '0');
				 read_en1  <= '0';
				 
             read_adr2 <= (others => '0');
             read_en2  <= '0';
				
             Output <= (others => '0');
             OutputRdy  <= '0';
           else
            
              if ReadEn = '1' then
				    read_adr1 <= Read_Adr;
					 read_en1 <= '1';
				  else
				    read_adr1 <= read_adr1 ;
					 read_en1  <= read_en1  ;
				  end if;
				  
				  if read_en1 ='1' then
				    read_adr2 <=read_adr1 ;
					 read_en2 <='1' ;
				  else
				    read_adr2 <= read_adr2;
					 read_en2  <= '0';
				  end if ;
				  -- after two rising-edge of clk data can be apear in output
				  if read_en2 ='1' then
				
				     Output <= ram_memory(to_integer(unsigned(read_adr2)));
                 OutputRdy  <= '1'; -- data is ready   
              else
				     Output <= ( others =>'0');
                 OutputRdy  <= '0'; -- Not ready 
				  end if; 
           end if;
        end if;
    end process; 
	 
end Behavioral;


