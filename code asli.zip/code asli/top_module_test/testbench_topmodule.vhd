
LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
 
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--USE ieee.numeric_std.ALL;
 
ENTITY test_bench_top IS
END test_bench_top;
 
ARCHITECTURE behavior OF test_bench_top IS 
 
    -- Component Declaration for the Unit Under Test (UUT)
 
    COMPONENT control
    PORT(
         Rst : IN  std_logic;
         clk : IN  std_logic;
         Input : IN  std_logic;
         InputRdy : IN  std_logic;
         Output : OUT  std_logic;
         OutputRdy : OUT  std_logic;
         Error : OUT  std_logic
        );
    END COMPONENT;
    

   --Inputs
   signal Rst : std_logic := '0';
   signal clk : std_logic := '0';
   signal Input : std_logic := '0';
   signal InputRdy : std_logic := '0';

 	--Outputs
   signal Output : std_logic;
   signal OutputRdy : std_logic;
   signal Error : std_logic;

   -- Clock period definitions
   constant clk_period : time := 10 ns;
 
BEGIN
 
	-- Instantiate the Unit Under Test (UUT)
   uut: control PORT MAP (
          Rst => Rst,
          clk => clk,
          Input => Input,
          InputRdy => InputRdy,
          Output => Output,
          OutputRdy => OutputRdy,
          Error => Error
        );

   -- Clock process definitions
   clk_process :process
   begin
		clk <= '0';
		wait for clk_period/2;
		clk <= '1';
		wait for clk_period/2;
   end process;
 

   -- Stimulus process
   stim_proc: process
   begin		
      -- hold reset state for 100 ns.
      wait for 100 ns;
		Rst <= '0';
		--write operation
      InputRdy <= '1'; --function
      Input <='1';
		wait for clk_period;
		Input <='1';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='1';
		InputRdy <='0';
		wait for clk_period;
		InputRdy <= '1';--address
      Input <='0';
		wait for clk_period;
		Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		InputRdy <='0';		
		wait for clk_period;
		InputRdy <= '1';--data
      Input <='1';
		wait for clk_period;
		Input <='1';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		InputRdy <='0';	
      wait for clk_period;		
		InputRdy <= '1';--checksumh
      Input <='0';
		wait for clk_period;
		Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		InputRdy <='0';
      wait for clk_period;      
		InputRdy <= '1';--checksuml
      Input <='0';
		wait for clk_period;
		Input <='0';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='1';
		InputRdy <='0';
		wait for 100 ns;
      --read operation
		InputRdy <= '1';--function
      Input <='0';
		wait for clk_period;
		Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='1';
		InputRdy <='0';
		wait for clk_period;
		InputRdy <= '1';--address
      Input <='0';
		wait for clk_period;
		Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		InputRdy <='0';
		wait for clk_period;
		InputRdy <= '1';--checksumh
      Input <='0';
		wait for clk_period;
		Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		InputRdy <='0';
      wait for clk_period;
		InputRdy <= '1';--checksuml
      Input <='0';
		wait for clk_period;
		Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='0';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='1';
		wait for clk_period;
      Input <='1';
		InputRdy <='0';
		wait for 100 ns;
		
		
      -- insert stimulus here 

      wait;
   end process;

END;
