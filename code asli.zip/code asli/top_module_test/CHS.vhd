library IEEE;                                                     -- Mobina Teromideh   40223021
use IEEE.STD_LOGIC_1164.ALL;                                      -- Zahraw Heydari     40223028
use IEEE.NUMERIC_STD.ALL;



entity checksum is
    Port ( clk : in  STD_LOGIC;
           Rst : in  STD_LOGIC;
           start : in  STD_LOGIC;
           byte_count : in  INTEGER range 2 to 4;
           byte0 : in  STD_LOGIC_VECTOR (7 downto 0);
           byte1 : in  STD_LOGIC_VECTOR (7 downto 0);
           byte2 : in  STD_LOGIC_VECTOR (7 downto 0);
           byte3 : in  STD_LOGIC_VECTOR (7 downto 0);
			  byte4 : in  STD_LOGIC_VECTOR (7 downto 0);
           checksumH : out  STD_LOGIC_VECTOR (7 downto 0);
           checksumL : out  STD_LOGIC_VECTOR (7 downto 0);
           ready : out  STD_LOGIC);
end checksum;

architecture Behavioral of checksum is

signal sum : unsigned(15 downto 0):= (others => '0') ;  -- 16 bits 

begin
process(clk)
variable temp : unsigned ( 15 downto 0);
begin
     if rising_edge(clk) then
	     -- reset
	     if Rst='1' then
		     checksumH <= ( others =>'0') ;
		     checksumL <= ( others =>'0') ;
			  sum <= (others => '0') ;
			  ready <= '0';
			  
			else
			  if start = '1' then     -- zero extension because they are unsigned numbers we resize them to 16 bits to add
			    temp :=  resize (unsigned(byte0) , 16) + resize (unsigned(byte1), 16);   -- without logical error
			    if byte_count >= 3 then
			       temp := temp  + resize (unsigned(byte2), 16 );
			    end if;
			    if byte_count >= 4 then
			       temp := temp  + resize (unsigned(byte3), 16 );
			    end if;
			    if byte_count = 5 then
			       temp := temp  + resize (unsigned(byte4), 16 );
			    end if;
			  
			    sum <= temp ;
			    checksumH <= std_logic_vector(temp(15 downto 8));
			    checksumL <= std_logic_vector(temp( 7 downto 0));
			    ready <= '1';
		    else
		       ready <= '0';
			    checksumH <= ( others =>'0') ;
		       checksumL <= ( others =>'0') ;
			 end if;
		  end if;
	  end if;
end process;
			  

end Behavioral;

