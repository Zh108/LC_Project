-- ZAHRA HEYDARI - 40223028
-- MOBINA TEROMIDEH - 40223021
-- FINAL PROJECT
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity logic_system_top is
  Port (
    clk        : in  STD_LOGIC;
    rst        : in  STD_LOGIC;

    -- incoming byte stream
    inputRdy  : in  STD_LOGIC;
    input     : in  STD_LOGIC;

    -- Hamming-coded serial output 
    output     : out STD_LOGIC;   
    outputRdy  : out STD_LOGIC;   

    -- status
    error_flag : out STD_LOGIC
  );
end logic_system_top;

architecture Behavioral of logic_system_top is



  ---------------------------------------------------------------------------
  -- function                                                                  
  ---------------------------------------------------------------------------
  constant FUNC_READ   : STD_LOGIC_VECTOR(7 downto 0) := "00001111" ;
  constant FUNC_WRITE  : STD_LOGIC_VECTOR(7 downto 0) := "11110000" ;

  signal is_operand_s  : boolean ;
  signal is_immediate_s: boolean ;
  signal is_array_s    : boolean ;
  signal is_indirect_s : boolean ;
  
  ---------------------------------------------------------------------------
  -- DECODER
  ---------------------------------------------------------------------------
    -- serial to 13bit 
    signal cw_shift     : STD_LOGIC_VECTOR(12 downto 0) := (others => '0');  -- shift register
    signal cw_reg       : STD_LOGIC_VECTOR(12 downto 0) := (others => '0');  
    signal cw_bit_cnt   : integer range 0 to 13 := 0;
    signal cw_ready     : STD_LOGIC := '0';  

    -- decoder outputs (internal)
    signal dec_byte_i   : STD_LOGIC_VECTOR(7 downto 0) := (others => '0');
    signal dec_valid_i  : STD_LOGIC := '0';

    -- registered handoff to packetizer / top outputs 
    signal dec_byte_q   : STD_LOGIC_VECTOR(7 downto 0) := (others => '0');
    signal dec_valid_q  : STD_LOGIC := '0';


  ---------------------------------------------------------------------------
  -- DATA PACKET
  ---------------------------------------------------------------------------
  signal dp_rdy                : STD_LOGIC;
  signal dp_func               : STD_LOGIC_VECTOR(7 downto 0) ;
  signal dp_addr1, dp_addr2    : STD_LOGIC_VECTOR(7 downto 0) ;
  signal dp_dest               : STD_LOGIC_VECTOR(7 downto 0) ;
  signal dp_data               : STD_LOGIC_VECTOR(7 downto 0) ;
  signal dp_len                : STD_LOGIC_VECTOR(7 downto 0) ;
  signal dp_chkh, dp_chkl      : STD_LOGIC_VECTOR(7 downto 0) ;

   ---------------------------------------------------------------------------
  -- CHECKSUM
  ---------------------------------------------------------------------------
  signal cks_start         : STD_LOGIC := '0';
  signal cks_ready         : STD_LOGIC;
  signal cks_H, cks_L      : STD_LOGIC_VECTOR(7 downto 0);
  signal cks_byte_cnt      : integer range 2 to 5 := 4;                                     --bayad range ro 5 bezarim ya 4? chera meghdar avalie dade 4?
  signal cks_b0, cks_b1, cks_b2, cks_b3, cks_b4 : STD_LOGIC_VECTOR(7 downto 0);

  ---------------------------------------------------------------------------
  -- CONTROL UNIT 
  ---------------------------------------------------------------------------
  signal cu_write_en, cu_read_en, cu_out_rdy, cu_error, cu_alu_en : STD_LOGIC;

  ---------------------------------------------------------------------------
  -- RAM (8 x 32)
  ---------------------------------------------------------------------------
  signal ram_wr_en      : STD_LOGIC;
  signal ram_wr_addr    : STD_LOGIC_VECTOR(7 downto 0);
  signal ram_wr_data    : STD_LOGIC_VECTOR(7 downto 0);  
  signal ram_rd_en      : STD_LOGIC;
  signal ram_rd_addr    : STD_LOGIC_VECTOR(7 downto 0); 
  signal ram_rd_out     : STD_LOGIC_VECTOR(7 downto 0);
  signal ram_rd_valid   : STD_LOGIC;
  signal ram_wr_ack     : STD_LOGIC;

  ---------------------------------------------------------------------------
  -- ALU
  ---------------------------------------------------------------------------
  --signal alu_write_en   : STD_LOGIC;
  --signal alu_write_addr : STD_LOGIC_VECTOR(7 downto 0);
  signal alu_write_data : STD_LOGIC_VECTOR(7 downto 0);
  signal alu_done       : STD_LOGIC;
  signal opA, opB       : STD_LOGIC_VECTOR(7 downto 0);  
  signal alu_overflow   : STD_LOGIC;
  
  ---------------------------------------------------------------------------
  -- Address ARRAY INDIRECT
  ---------------------------------------------------------------------------
  type READSEL_T is (RS_ADDR1, RS_ADDR2, RS_ARRAY_A, RS_ARRAY_B, RS_IND_PTR, RS_IND_DATA);
  signal read_sel : READSEL_T := RS_ADDR1;

  -- ARRAY iterator (0 .. len-1)
  signal arr_idx     : unsigned(7 downto 0) := (others=>'0');
  signal arr_len_u   : unsigned(7 downto 0) := (others=>'0');
  signal arr_active  : STD_LOGIC := '0';

  -- INDIRECT pointer value 
  signal ind_ptr     : STD_LOGIC_VECTOR(7 downto 0) := (others=>'0');
  signal ind_stage   : integer range 0 to 2 := 0;  -- 0=need ptr, 1=need data, 2=ready

  signal next_is_A   : STD_LOGIC := '1';


  ---------------------------------------------------------------------------
  -- ENCODER            
  ---------------------------------------------------------------------------
  signal enc_rst      : STD_LOGIC := '1';
  signal enc_bit      : STD_LOGIC;
  signal tx_data_reg  : STD_LOGIC_VECTOR(7 downto 0) := (others=>'0');
  signal tx_cnt       : integer range 0 to 12 := 0;
  type TX_STATE_T is (TX_IDLE, TX_ARM, TX_SHIFT);
  signal tx_state     : TX_STATE_T := TX_IDLE; 

begin
  ----------------------------------------------------------------------------
  -- choose function
  ----------------------------------------------------------------------------
  is_operand_s   <= (dp_func="00000000") or (dp_func="00000001") or (dp_func="00000010") or (dp_func="00000011");
  is_immediate_s <= (dp_func="00111100") or (dp_func="00111101") or (dp_func="00111110") or (dp_func="00111111");
  is_array_s     <= (dp_func="11000000") or (dp_func="11000001") or (dp_func="11000010") or (dp_func="11000011");
  is_indirect_s  <= (dp_func="00110000") or (dp_func="00110001") or (dp_func="00110010") or (dp_func="00110011");
  
  ----------------------------------------------------------------------------
  -- DECODER
  ----------------------------------------------------------------------------

   process(clk)
	begin
		if rising_edge(clk) then
			if Rst = '1' then
				cw_shift   <= (others => '0');
				cw_reg     <= (others => '0');
				cw_bit_cnt <= 0;
				cw_ready   <= '0';
			else
				cw_ready <= '0';  -- default

				if inputRdy = '1' then
					-- LSB-first
					cw_shift <= input & cw_shift(12 downto 1);
					cw_bit_cnt <= cw_bit_cnt + 1;

					if cw_bit_cnt = 12 then         -- 13th bit
						cw_reg     <= cw_shift(11 downto 0) & input;  -- freeze codeword for decoder
						cw_bit_cnt <= 0;
						cw_ready   <= '1';             -- one-cycle strobe
					end if;
				end if;
			end if;
		end if;
	end process;
	
		process(clk)
		begin
			if rising_edge(clk) then
				if Rst = '1' then
					dec_byte_q  <= (others => '0');
					dec_valid_q <= '0';
				else
					-- default: no valid strobe
					dec_valid_q <= '0';

					-- When we just finished collecting 13 bits:
					if cw_ready = '1' then
					-- latch the decoder's result into a register
					dec_byte_q  <= dec_byte_i;   -- 8-bit decoded data
					dec_valid_q <= dec_valid_i;  -- 1-cycle pulse showing it's valid
					end if;
				end if;
			end if;
		end process;

	
		u_dec : entity work.hamming_decoder
		port map (
		DataIn   => cw_reg,       
		clk      => clk,
		Rst      => Rst,
		Odd_Mode => '0' ,     
		DataOut  => dec_byte_i,   
		Valid    => dec_valid_i
		);

  ----------------------------------------------------------------------------
  -- DATA PACKET
  ----------------------------------------------------------------------------
  U_DP: entity work.dataPacket
    port map (
      clk           => clk,
      rst           => rst,
      input_rdy     => dec_valid_i,
      input_byte    => dec_byte_i,
      output_rdy    => dp_rdy,
      function_code => dp_func,
      addr1         => dp_addr1,
      addr2         => dp_addr2,
      des_addr_out  => dp_dest,
      checksumH     => dp_chkh,
      checksumL     => dp_chkl,
      lenght        => dp_len,
      data_out      => dp_data
    );

  ----------------------------------------------------------------------------
  -- Checksum                                                                             
  --------------------------------------------------------------------------

	process(dp_func, dp_addr1, dp_addr2, dp_dest, dp_data, dp_len)
	begin
		-- defaults
		cks_b0    <= dp_func;
		cks_b1    <= dp_addr1;
		cks_b2    <= (others => '0');
		cks_b3    <= (others => '0');
		cks_b4    <= (others => '0');
		cks_byte_cnt <= 2;

		-- Operand ALU: F, A1, A2, Dest
		if    (dp_func = "00000000") or (dp_func = "00000001") or
				(dp_func = "00000010") or (dp_func = "00000011") then
			cks_b2    <= dp_addr2;
			cks_b3    <= dp_dest;
			cks_byte_cnt <= 4;

		-- Write: F, A1, Data
		elsif (dp_func = "11110000") then
			cks_b2    <= dp_data;
			cks_byte_cnt <= 3;

		-- Read: F, A1
		elsif (dp_func = "00001111") then
			cks_byte_cnt <= 2;

		-- Immediate ALU: F, A1, Data, Dest
		elsif (dp_func = "00111100") or (dp_func = "00111101") or
				(dp_func = "00111110") or (dp_func = "00111111") then
			cks_b2    <= dp_data;
			cks_b3    <= dp_dest;
			cks_byte_cnt <= 4;

		-- Array ALU: F, A1, Data, Length
		elsif (dp_func = "11000000") or (dp_func = "11000001") or
				(dp_func = "11000010") or (dp_func = "11000011") then
			cks_b2    <= dp_data;
			cks_b3    <= dp_len;
			cks_byte_cnt <= 4;

		-- Indirect: F, A1, Data
		elsif (dp_func = "00110000") or (dp_func = "00110001") or
				(dp_func = "00110010") or (dp_func = "00110011") then
			cks_b2    <= dp_data;
			cks_byte_cnt <= 3;

		else
			cks_byte_cnt <= 2;
		end if;
	end process;

  U_CKS: entity work.checksum
    port map (
      clk        => clk,
      Rst        => rst,
      start      => cks_start,
      byte_count => cks_byte_cnt,
      byte0      => cks_b0,
      byte1      => cks_b1,
      byte2      => cks_b2,
      byte3      => cks_b3,
      byte4      => cks_b4,
      checksumH  => cks_H,
      checksumL  => cks_L,
      ready      => cks_ready
    );

  ----------------------------------------------------------------------------
  -- Control Unit
  ----------------------------------------------------------------------------
  U_CU: entity work.controlUnit_asli
    port map (
      clk        => clk,
      rst        => rst,
      func       => dp_func,
      checkSumH  => dp_chkh,
      checkSumL  => dp_chkl,
      computedH  => cks_H,
      computedL  => cks_L,
      lengthh    => dp_len,
      write_en   => cu_write_en,
      read_en    => cu_read_en,
      outputRdy  => cu_out_rdy,
      error      => cu_error,
      alu_en     => cu_alu_en
    );

  error_flag    <= cu_error;  --- %%%%%%%%%%%%%%%%%%%%%age jaye dige ham error darim mitoonim bhham or konim beshe error _ flag
  --ram_out       <= ram_rd_out;
  --ram_out_valid <= ram_rd_valid;
  --if ((cu_write_en) and (

  ----------------------------------------------------------------------------
  -- RAM
  ----------------------------------------------------------------------------
  U_RAM: entity work.RAM
    port map (
      clk         => clk,
      Rst         => rst,
      Write_Adr   => ram_wr_addr,
      WriteEn     => ram_wr_en,
      Wr_Data     => ram_wr_data,
      Read_Adr    => ram_rd_addr,
      ReadEn      => ram_rd_en,
      Output      => ram_rd_out,
      wr_data_ack => ram_wr_ack,
      OutputRdy   => ram_rd_valid
    );

  ----------------------------------------------------------------------------
  -- ALU
  ----------------------------------------------------------------------------
  U_ALU: entity work.ALU
    port map (
      clk          => clk,
      rst          => rst,
      enable       => cu_alu_en,
      func         => dp_func,
      data1        => opA,
      data2        => opB,
      result       => alu_write_data,
      done         => alu_done,
		overflow     => alu_overflow
    );

  ----------------------------------------------------------------------------
  -- ARRAY & INDIRECT 
  ----------------------------------------------------------------------------
  process(clk, rst)
  begin
    if rst='1' then
      arr_idx    <= (others=>'0');   
      arr_len_u  <= (others=>'0');   
      arr_active <= '0';
      ind_ptr    <= (others=>'0');
      ind_stage  <= 0;
    elsif rising_edge(clk) then
      if dp_rdy='1' then
        if is_array_s then
          arr_len_u  <= unsigned(dp_len);                               -- unsigned %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
          arr_idx    <= (others=>'0');
          arr_active <= '1';
        else
          arr_active <= '0';
        end if;

        if is_indirect_s then
          ind_stage <= 0;
        end if;
      end if;

      if arr_active='1' and cu_write_en='1' then
        if arr_idx + 1 >= arr_len_u then                              
          arr_active <= '0';
        else
          arr_idx <= arr_idx + 1;
        end if;
      end if;

      if is_indirect_s then                                              
        if (ind_stage=0) and (ram_rd_valid='1') then
          ind_ptr   <= ram_rd_out;
          ind_stage <= 1;
        elsif (ind_stage=1) and (ram_rd_valid='1') then
          ind_stage <= 2;
        end if;
      end if;
    end if;
  end process;
 

  ----------------------------------------------------------------------------
  -- RAM outputs into opA/opB 
  ----------------------------------------------------------------------------
  process(clk, rst)
  begin
    if rst='1' then
      next_is_A <= '1';                                                                         --%%%%%
      opA <= (others=>'0');
      opB <= (others=>'0');
    elsif rising_edge(clk) then
      if is_immediate_s or is_indirect_s then
        opB <= dp_data;
      end if;

      if ram_rd_valid='1' then
        if next_is_A='1' then
          opA <= ram_rd_out;
          next_is_A <= '0';
        else
          if is_indirect_s then
            opA <= ram_rd_out;  -- second read is the pointed data
          else
            opB <= ram_rd_out;  -- normal B
          end if;
          next_is_A <= '1';
        end if;
      end if;
    end if;
  end process;

  ----------------------------------------------------------------------------
  -- RAM WRITE
  ----------------------------------------------------------------------------
    ram_wr_en    <= '1' when((alu_done = '1') or ((cu_write_en = '1') and (dp_func = "11110000"))) else '0';
    ram_wr_addr  <= dp_dest when (alu_done='1') else dp_addr1;
    ram_wr_data  <= alu_write_data when (alu_done='1') else dp_data;

  ----------------------------------------------------------------------------
  -- Hamming ENCODER
  ----------------------------------------------------------------------------
  U_ENC: entity work.hamming_encoder
    port map (
      clk      => clk,
      Rst      => enc_rst,       -- hold in reset when idle
      Data     => tx_data_reg,
      Odd_Mode => '0',
      DataOut  => enc_bit
    );

  output <= enc_bit;
  outputRdy <= '1' when tx_state = TX_SHIFT else '0';

  process(clk, rst)
  begin
    if rst='1' then
      tx_state    <= TX_IDLE;
      enc_rst     <= '1';
      tx_cnt      <= 0;
      tx_data_reg <= (others=>'0');
    elsif rising_edge(clk) then
      case tx_state is
        when TX_IDLE =>
          enc_rst <= '1';
          tx_cnt  <= 0;
          if (dp_func=FUNC_READ) and (ram_rd_valid='1') then
            tx_data_reg <= ram_rd_out;
            tx_state    <= TX_ARM;
          end if;

        when TX_ARM =>
          enc_rst  <= '0';
          tx_cnt   <= 0;
          tx_state <= TX_SHIFT;

        when TX_SHIFT =>
          enc_rst <= '0';
          if tx_cnt=12 then
            enc_rst  <= '1';
            tx_state <= TX_IDLE;
            tx_cnt   <= 0;
          else
            tx_cnt <= tx_cnt + 1;
          end if;
      end case;
    end if;
  end process;

end Behavioral;
