library IEEE;                                            -- Mobina Teromideh  40223021
use IEEE.STD_LOGIC_1164.ALL;                             -- Zahra Heydari     40223028
use IEEE.NUMERIC_STD.ALL;


entity hamming_encoder is
    Port ( clk : in  STD_LOGIC;
           Rst : in  STD_LOGIC;
           Data : in  STD_LOGIC_VECTOR (7 downto 0);
           Odd_Mode : in  STD_LOGIC;      
           DataOut : out  STD_LOGIC);
end hamming_encoder;

architecture Behavioral of hamming_encoder is


signal encoded_data :std_logic_vector(12 downto 0);
signal bit_counter : integer range 0 to 12 :=0;
signal p1,p2,p4,p8 : std_logic; -- parities ( P1 P2 P4 P8)
signal parity: std_logic; -- last bit P13


begin

process(clk)
begin
    if rising_edge(clk) then
	    if Rst = '1' then
		     bit_counter<= 0;
		     DataOut <= '0'; -- reset
		 else
		 
		     p1 <= Data(0) xor Data(1) xor Data(3) xor Data(4) xor Data(6) ; --P1
			  p2 <= Data(0) xor Data(2) xor Data(3) xor Data(5) xor Data(6) ; --P2
			  p4 <= Data(1) xor Data(2) xor Data(3) xor Data(7) ; --P4
			  p8 <= Data(4) xor Data(5) xor Data(6) xor Data(7) ; --P8
			  
			  parity <= p1 xor p2 xor p4 xor p8 xor Odd_Mode xor
			            Data(0) xor Data(1) xor Data(2) xor Data(3) xor Data(4) xor
							Data(5) xor Data(6) xor Data(7);
			  
		     encoded_data(0 ) <= p1 xor Odd_Mode ; 
			  encoded_data(1 ) <= p2 xor Odd_Mode ; 
			  encoded_data(2 ) <= Data(0);
			  encoded_data(3 ) <= p4 xor Odd_Mode ; 
			  encoded_data(4 ) <= Data(1);
			  encoded_data(5 ) <= Data(2);
			  encoded_data(6 ) <= Data(3);
			  encoded_data(7 ) <= p8 xor Odd_Mode ; 
			  encoded_data(8 ) <= Data(4);
			  encoded_data(9 ) <= Data(5);			  
			  encoded_data(10) <= Data(6); 
			  encoded_data(11) <= Data(7); 
			  encoded_data(12) <= parity ; 
			  
			  if bit_counter <13 then
			     DataOut <= encoded_data(bit_counter);
				  bit_counter <= bit_counter +1 ;
			  else
			     bit_counter <= 0 ;
			  end if;
		end if;
	end if;
end process;
end Behavioral;


