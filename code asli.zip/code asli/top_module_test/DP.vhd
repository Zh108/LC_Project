-- data packet ( control unit ghabli) (module data packet digar ham check shavad)
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity dataPacket is
    Port (
        clk          : in  STD_LOGIC;
        rst          : in  STD_LOGIC;
        input_rdy    : in  STD_LOGIC;
        input_byte   : in  STD_LOGIC_VECTOR(7 downto 0);
        output_rdy   : out STD_LOGIC;
        -- Add outputs to ALU, RAM
        function_code : out STD_LOGIC_VECTOR(7 downto 0);
        addr1         : out STD_LOGIC_VECTOR(7 downto 0);
        addr2         : out STD_LOGIC_VECTOR(7 downto 0);
		  des_addr_out  : out STD_LOGIC_VECTOR(7 downto 0);
		  checksumH     : out STD_LOGIC_VECTOR(7 downto 0);
		  checksumL     : out STD_LOGIC_VECTOR(7 downto 0);
		  lenght        : out STD_LOGIC_VECTOR(7 downto 0);
        data_out      : out STD_LOGIC_VECTOR(7 downto 0)
    );
end dataPacket;

architecture Behavioral of dataPacket is

    type State_Type is ( 
        IDLE, READ_FUNC, READ_ADDR1, READ_ADDR2, DES_ADDR ,READ_DATA, READ_LENGTH, READ_CHECKSUM_H, READ_CHECKSUM_L,DONE,EXECUTE
    );
    signal current_state, next_state : State_Type;

    -- signal byte_counter : integer range 0 to 10 := 0;

    signal func_reg         : STD_LOGIC_VECTOR(7 downto 0) := (others => '0');
    signal addr1_reg        : STD_LOGIC_VECTOR(7 downto 0) := (others => '0');
    signal addr2_reg        : STD_LOGIC_VECTOR(7 downto 0) := (others => '0');
    signal data_reg         : STD_LOGIC_VECTOR(7 downto 0) := (others => '0');
	 signal des_addr_reg     : STD_LOGIC_VECTOR(7 downto 0) := (others => '0');
	 signal checksumH_reg    : STD_LOGIC_VECTOR(7 downto 0) := (others => '0');
	 signal checksumL_reg    : STD_LOGIC_VECTOR(7 downto 0) := (others => '0');
	 signal lenght_reg       : STD_LOGIC_VECTOR(7 downto 0) := (others => '0');

begin

    
    process(clk, rst)
    begin
        if rst = '1' then
            current_state <= IDLE;
            -- byte_counter <= 0;
        elsif rising_edge(clk) then
            current_state <= next_state;
        end if;
    end process;

    -- FSM logic
    process(current_state, input_rdy )
    begin
        case current_state is
            when IDLE =>
                if input_rdy = '1' then
                    next_state <= READ_FUNC;
                else
                    next_state <= IDLE;
                end if;

            when READ_FUNC =>
                func_reg <= input_byte;
                next_state <= READ_ADDR1;

            when READ_ADDR1 =>
                addr1_reg <= input_byte;
               
                if (func_reg = "00000000" or func_reg = "00000001" or func_reg = "00000010" or func_reg = "00000011")then -- Operand ALU
                    next_state <= READ_ADDR2;
					 elsif func_reg = "11110000" then -- Write
                    next_state <= READ_DATA;
					 elsif func_reg = "00001111" then -- Read
                    next_state <= READ_CHECKSUM_H;  
                elsif (func_reg = "00111100" or func_reg = "00111101" or func_reg = "00111110" or func_reg = "00111111") then -- Immediate 
                    next_state <= READ_DATA;
					 elsif (func_reg = "11000000" or func_reg = "11000001" or func_reg = "11000010" or func_reg = "11000011") then -- Array 
                    next_state <= READ_DATA;
					 elsif (func_reg = "00110000" or func_reg = "00110001" or func_reg = "00110010" or func_reg = "00110011") then -- Indirect 
                    next_state <= READ_DATA;
                else
                    next_state <= EXECUTE;
                end if;

            when READ_ADDR2 =>
                addr2_reg <= input_byte;       
                next_state <= DES_ADDR;
            

            when READ_DATA =>
                data_reg <= input_byte;
					 
					 if func_reg = "11110000" then -- Write
                    next_state <= READ_CHECKSUM_H; 
                elsif (func_reg = "00111100" or func_reg = "00111101" or func_reg = "00111110" or func_reg = "00111111") then -- Immediate 
                    next_state <= DES_ADDR;
					 elsif (func_reg = "11000000" or func_reg = "11000001" or func_reg = "11000010" or func_reg = "11000011") then -- Array 
                    next_state <= READ_LENGTH;
					 elsif (func_reg = "00110000" or func_reg = "00110001" or func_reg = "00110010" or func_reg = "00110011") then -- Indirect 
                    next_state <= DES_ADDR;
                else
                    next_state <= EXECUTE;
                end if;
					 
			   when READ_LENGTH =>
                lenght_reg <= input_byte;
                next_state <= DES_ADDR;
				
				when DES_ADDR =>
                des_addr_reg <= input_byte;
                next_state <= READ_CHECKSUM_H;
				
				when READ_CHECKSUM_H =>
                checksumH_reg <= input_byte;
                next_state <= READ_CHECKSUM_L;
					 
				when READ_CHECKSUM_L =>
                checksumL_reg <= input_byte;
                next_state <= DONE;
				
				when EXECUTE =>
                next_state <= DONE;

            when DONE =>
                output_rdy <= '1';
                next_state <= IDLE;

            when others =>
                next_state <= IDLE;
        end case;
    end process;

    -- Outputs
    function_code <= func_reg;
    addr1         <= addr1_reg;
    addr2         <= addr2_reg;
    data_out      <= data_reg;
	 des_addr_out  <= des_addr_reg;
    checksumH     <= checksumH_reg;
	 checksumL     <= checksumL_reg;
    lenght        <= lenght_reg;

end Behavioral;
